from setuptools import setup, find_packages

setup(
    name='MeowkitPy',
    version='0.1.0',
    description='Meowlien Studio\'s kit tools for Flask',
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
    # Other metadata (author, license, etc.)
)